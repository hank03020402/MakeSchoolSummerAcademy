//: Playground - noun: a place where people can play

import UIKit
import Foundation

func paidrome(string:String)->Bool{
    let characters = Array(string.characters)
    for i in 1...characters.count{
        guard characters[i-1] == characters[characters.count-i] else{
            return false
        }
}
    return true
}

paidrome(string: "racecar")
